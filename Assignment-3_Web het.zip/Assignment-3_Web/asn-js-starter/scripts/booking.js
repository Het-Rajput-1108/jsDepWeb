/********* create variables *********/
// useful variables might be: the cost per day, the number of days selected, and elements on the screen that will be clicked or will need to be modified.
// Do any of these variables need to be initialized when the page is loaded?
// When do they need to be reset or updated?

let selectedDay = [
  document.getElementById("monday"),
  document.getElementById("tuesday"),
  document.getElementById("wednesday"),
  document.getElementById("thursday"),
  document.getElementById("friday"),
];
let totalDaysSelected = 0;
let clearButton = document.getElementById("clear-button");
let cost = document.getElementById("calculated-cost");
let halfButton = document.getElementById("half");
let dailyRate = 35;
let fullButton = document.getElementById("full");

/********* colour change days of week *********/
// when the day buttons are clicked, we will apply the "clicked" class to that element, and update any other relevant variables. Then, we can recalculate the total cost.
// added challenge: don't update the dayCounter if the same day is clicked more than once. hint: .classList.contains() might be helpful here!

for (let day of selectedDay) {
  day.addEventListener("click", function () {
    day.classList.contains("clicked")
      ? (totalDaysSelected = totalDaysSelected)
      : (totalDaysSelected += 1);
    this.className = "clicked";
    calculateCost();
  });
}

/********* clear days *********/
// when the clear-button is clicked, the "clicked" class is removed from all days, any other relevant variables are reset, and the calculated cost is set to 0.

function clearDay() {
  totalDaysSelected = 0;
  let clear = document.querySelectorAll("#weekday");
  for (let day of clear) {
    day.className = "blue-hover";
  }
  cost.innerHTML = 0;
  location.reload();
}

clearButton.addEventListener("click", clearDay);

/********* change rate *********/
// when the half-day button is clicked, set the daily rate to $20, add the "clicked" class to the "half" element, remove it from the "full" element, and recalculate the total cost.

function halfDay() {
  dailyRate = 20;
  halfButton.className = "clicked";
  fullButton.className = "blue-hover";
  calculateCost();
}

halfButton.addEventListener("click", halfDay);

// when the full-day button is clicked, the daily rate is set back to $35, the clicked class is added to "full" and removed from "half", and the total cost is recalculated.

function fullDay() {
  dailyRate = 35;
  halfButton.className = "blue-hover";
  fullButton.className = "clicked";
  calculateCost();
}

fullButton.addEventListener("click", fullDay);

/********* calculate *********/
// when a calculation is needed, set the innerHTML of the calculated-cost element to the appropriate value

function calculateCost() {
  let weekCost = dailyRate * totalDaysSelected;
  cost.innerHTML = weekCost;
}
